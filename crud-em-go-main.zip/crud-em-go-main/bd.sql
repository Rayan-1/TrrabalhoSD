create table aluno(
    ´nome´ VARCHAR(100),
    ´idade´ INTEGER,
    ´matricula´ INTEGER,
    ´curso´ VARCHAR(100) ,
    ´id´ INTEGER PRIMARY KEY AUTO_INCREMENT
)